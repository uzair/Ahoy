//
//  WebServiceUrl.swift
//  AhoyTest
//
//  Created by Uzair on 08/12/2020.
//

import UIKit



struct WebServiceUrl {
    
    static let baseUrl = Utility.getBaseUrl()
    static let apiKey = Utility.getApiKey()
    
    static let weatherUrl = baseUrl + "data/2.5/forecast?q="

}
