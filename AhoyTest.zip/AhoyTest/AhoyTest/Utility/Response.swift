//
//  Response.swift
//  JobLogic
//
//  Created by Imran Khan on 19/01/2017.
//  Copyright © 2017 Imran Khan. All rights reserved.
//

import Foundation

enum FailureCode:Int {
    case VALIDATION = 1000
    case OTHER = 2000
    case NONE = -1
}

enum ResponseStatus {
    case SUCCESS
    case FAILURE
    case ERROR
}

// MARK: - Response

class Response<T> {
    
    var data:T?
    var status:ResponseStatus
    var errors:[Error]?
    var failureMessage:String?
    var failureCode:FailureCode
    
    
    init() {
        self.status = ResponseStatus.SUCCESS
        self.errors = [Error]()
        self.failureCode = .NONE
    }
    
    init(withData data:T) {
        self.status = ResponseStatus.SUCCESS
        self.data = data
        self.failureCode = .NONE
    }
    
    init(withError error:Error) {
        self.status = ResponseStatus.ERROR
        self.errors = [Error]()
        self.errors?.append(error)
        self.failureCode = .NONE

    }
    
    init(withErrors errors:[Error]) {
        self.status = ResponseStatus.ERROR
        self.errors = [Error]()
        self.errors = errors
        self.failureCode = .NONE
        
    }
    
    init(withFailureMessage message:String) {
        self.status = ResponseStatus.FAILURE
        self.failureMessage = message
        self.failureCode = .NONE

    }
    
    init(withFailureMessage message:String, failureCode: FailureCode) {
        self.status = ResponseStatus.FAILURE
        self.failureMessage = message
        self.failureCode = failureCode

    }
    
}


