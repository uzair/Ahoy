//
//  Constants.swift
//  AhoyTest
//
//  Created by Uzair on 08/12/2020.
//

import Foundation

enum TempratureNotation : Int, Codable {
    
    case celcius = 1
    case fahrenheit = 2

}

let TempratureNotationChanged = "TempratureNotationChanged"
let TempratureNotationKey = "TempratureNotationKey"
let DetailSegue = "detailSegue"
let SettingsSegue = "settingsSegue"
let City = "dubai"
let SetNotification = "setNotification"
let WeatherForecast = "weatherForecast"
let NotificationAlreadySet = "notificationAlreadySet"


enum Environment {
    case development
    case staging
    case production
}
 

let environment: Environment = .production

