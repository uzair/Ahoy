//
//  Utility.swift
//  AhoyTest
//
//  Created by Uzair on 07/12/2020.
//

import Foundation
import SystemConfiguration
import UserNotifications

extension Double {
    func getDateStringFromUTC() -> String {
        let date = Date(timeIntervalSince1970: self)
        
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US")
        dateFormatter.dateStyle = .medium
        
        return dateFormatter.string(from: date)
    }
}

class Utility: NSObject {
    
    static func saveDataForOfflineUsage(withData data:[Any]) {
        
        if let savedData = try? NSKeyedArchiver.archivedData(withRootObject: data, requiringSecureCoding: false) {
            let defaults = UserDefaults.standard
            defaults.set(savedData, forKey: WeatherForecast)
        }
    }
    
    static func getOfflineData() -> [Any]? {
        
        let defaults = UserDefaults.standard
        
        if let savedWeatherForecast = defaults.object(forKey: WeatherForecast) as? Data {
            if let decodedWeatherForecast = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(savedWeatherForecast) as? [Weather] {
                let weatherForecast = decodedWeatherForecast
                return weatherForecast
            }
            
        }
        return nil
    }
    
    static func scheduleNotification() {
        
        if (!UserDefaults.standard.bool(forKey: NotificationAlreadySet)){
        
        let center = UNUserNotificationCenter.current()
        
        let content = UNMutableNotificationContent()
        content.title = "Weather updates"
        content.body = "Open the app to get weather forcasts"
        content.categoryIdentifier = "alarm"
        content.userInfo = ["customData": "ahoy"]
        content.sound = UNNotificationSound.default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 60, repeats: true)
        
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        center.add(request)
            
            UserDefaults.standard.set(true, forKey: NotificationAlreadySet)
          
            
        }
        
    }
    
    static func getOnlyDate(from date: Date?) -> Date? {
        var components: DateComponents? = nil
        if let date = date {
            components = Calendar.current.dateComponents(
                [.year, .month, .day],
                from: date)
        }
        if let components = components {
            return Calendar.current.date(
                from: components)
        }
        return nil
    }
    
    static func getBaseUrl() -> String  {
        
        switch environment {
        case .development:
            return "http://dev.api.openweathermap.org/"
            
        case .staging:
            // set web service URL to staging
            // set API keys to development
            return "http://staging.api.openweathermap.org/"
        case .production:
            // set web service URL to production
            // set API keys to production
            return "http://api.openweathermap.org/"
            
        }
    }
    
    static func getApiKey() -> String {
        
        switch environment {
        case .development:
            return "78e9fd9058a2476ddd55504a6593ab30"
            
        case .staging:
            // set web service URL to staging
            // set API keys to development
            return "78e9fd9058a2476ddd55504a6593ab30"
        case .production:
            // set web service URL to production
            // set API keys to production
            
            return "78e9fd9058a2476ddd55504a6593ab30"
            
        }
    }
    
    static func isConnectedToInternet() -> Bool {
        
        guard let reachability = SCNetworkReachabilityCreateWithName(nil, "www.google.com") else { return false}
        
        var flags = SCNetworkReachabilityFlags()
        SCNetworkReachabilityGetFlags(reachability, &flags)
        
        if !isNetworkReachable(with: flags) {
            // Device doesn't have internet connection
            return false
        }
        
        #if os(iOS)
        // It's available just for iOS because it's checking if the device is using mobile data
        if flags.contains(.isWWAN) {
            // Device is using mobile data
            return true
        }
        #endif
        
        // At this point we are sure that the device is using Wifi since it's online and without using mobile data
        return true
    }
    
    static func isNetworkReachable(with flags: SCNetworkReachabilityFlags) -> Bool {
        let isReachable = flags.contains(.reachable)
        let needsConnection = flags.contains(.connectionRequired)
        let canConnectAutomatically = flags.contains(.connectionOnDemand) || flags.contains(.connectionOnTraffic)
        let canConnectWithoutUserInteraction = canConnectAutomatically && !flags.contains(.interventionRequired)
        
        return isReachable && (!needsConnection || canConnectWithoutUserInteraction)
    }
    
    
    
}
