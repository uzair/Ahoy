//
//  SettingsViewController.swift
//  AhoyTest
//
//  Created by Uzair on 08/12/2020.
//

import UIKit

class SettingsViewController: UIViewController, ISettingsView {
    
    func applySettingsBtnTapped() {
        
        if (self.celciusBtn.isSelected) {
            // Write/Set Raw Value in User Defaults
            UserDefaults.standard.set(TempratureNotation.celcius.rawValue, forKey: TempratureNotationKey)
        }
        else if (self.fahrenheitBtn.isSelected) {
            
            // Write/Set Raw Value in User Defaults
            UserDefaults.standard.set(TempratureNotation.fahrenheit.rawValue, forKey: TempratureNotationKey)
        }
        
        UserDefaults.standard.synchronize()
        
        // post a notification
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: TempratureNotationChanged), object: nil, userInfo: nil)
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func celciusBtnTapped() {
        
        self.updateCelciusButtonUIAfterSelection()
    }
    
    func fahrenheitBtnTapped() {
        
        self.updateFahrenhietButtonUIAfterSelection()
    }
    
    
    var mPresenter: SettingsPresenter!
    
    @IBOutlet weak var celciusBtn: UIButton!
    @IBOutlet weak var fahrenheitBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.title = "Settings"
        
        mPresenter = SettingsPresenter(withSettingsView: self)
        
        self.initializeUI()
        
        
    }
    
    func initializeUI() {
        
        let rawValue = UserDefaults.standard.integer(forKey: TempratureNotationKey)
        if ((rawValue) != 0){
            
            tempratureNotation = TempratureNotation(rawValue: rawValue)!
            
        }
        
        switch tempratureNotation {
        case .celcius:
            self.updateCelciusButtonUIAfterSelection()
            break
        case .fahrenheit:
            self.updateFahrenhietButtonUIAfterSelection()
            break
        }
    }
    
    func updateCelciusButtonUIAfterSelection() {
        
        self.celciusBtn.isSelected = !self.celciusBtn.isSelected
        self.fahrenheitBtn.isSelected = false
        
    }
    
    func updateFahrenhietButtonUIAfterSelection() {
        
        self.fahrenheitBtn.isSelected = !self.fahrenheitBtn.isSelected
        self.celciusBtn.isSelected = false
    }
    
    
    // MARK: - IBActions
    
    @IBAction func celciusBtnAction(_ sender : AnyObject){
        self.mPresenter.celciusBtnTapped()
    }
    
    @IBAction func fahrenheitBtnAction(_ sender: AnyObject) {
        self.mPresenter.fahrenheitBtnTapped()
    }
    
    @IBAction func applySettingsBtnAction(_ sender: AnyObject) {
        self.mPresenter.applySettingsBtnTapped()
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
