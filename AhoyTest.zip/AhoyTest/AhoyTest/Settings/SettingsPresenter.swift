//
//  SettingsPresenter.swift
//  AhoyTest
//
//  Created by Uzair on 08/12/2020.
//

import Foundation

class SettingsPresenter: NSObject {
    
    private var mView:ISettingsView
    
    init (withSettingsView settingsView:ISettingsView) {
        self.mView = settingsView
        
    }
    
    func celciusBtnTapped() {
        self.mView.celciusBtnTapped()
    }
    
    func fahrenheitBtnTapped() {
        self.mView.fahrenheitBtnTapped()
    }
    
    func applySettingsBtnTapped() {
        self.mView.applySettingsBtnTapped()
        
    }
}

