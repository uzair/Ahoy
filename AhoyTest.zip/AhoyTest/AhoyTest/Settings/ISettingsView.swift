//
//  ISettingsView.swift
//  AhoyTest
//
//  Created by Uzair on 08/12/2020.
//

import Foundation

protocol ISettingsView{

    func celciusBtnTapped()
    func fahrenheitBtnTapped()
    func applySettingsBtnTapped()

}
