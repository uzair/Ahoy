//
//  WeatherListPresenter.swift
//  AhoyTest
//
//  Created by Uzair on 07/12/2020.
//

import UIKit

class WeatherListPresenter: NSObject {
    
    private var mView:IWeatherListView
    private var mWeatherService:IWeatherService
    
    init(withVisitService weatherService:IWeatherService, weatherListView:IWeatherListView) {
        self.mView = weatherListView
        self.mWeatherService = weatherService
        
    }
    
    func getWeather(forCity city:String) {
        
        self.mView.showLoader()
        
        // Read/Get Raw Value from User Defaults
        let rawValue = UserDefaults.standard.integer(forKey: TempratureNotationKey)
        if ((rawValue) != 0){
            
            UserDefaults.standard.set(rawValue, forKey: TempratureNotationKey)
            tempratureNotation = TempratureNotation(rawValue: rawValue)!
            
        }
        
        self.mWeatherService.getWeather(forCity: city, withTempratureNotation: tempratureNotation) { (cResponse) in
            
            
            
            self.mView.hideLoader()
            
            switch cResponse.status {
            case .SUCCESS:
                if let weather = cResponse.data {
                    self.mView.showWeatherList(weatherList: weather)
                }
                
                
                break
                
            case .FAILURE:
                if let msg = cResponse.failureMessage {
                    self.mView.showErrorMessage(msg: msg)
                }
                
                break
            case .ERROR:
                if let error = cResponse.errors?.first {
                    self.mView.showErrorMessage(msg: error.localizedDescription)
                }
                break
            }
            
        }
        
    }
    
    
    func weatherCellTapped() {
        
        self.mView.navigateToWeatherDetail()
    }
    
    func settingsButtonTapped() {
        self.mView.showSettingsScreen()
    }
    
}

