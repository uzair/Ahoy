//
//  WeatherListViewController.swift
//  AhoyTest
//
//  Created by Uzair on 07/12/2020.
//

import UIKit
import Alamofire

var tempratureNotation:TempratureNotation = .celcius

class WeatherListViewController: UIViewController, IWeatherListView, UITableViewDataSource, UITableViewDelegate {
    
    var mWeatherService: IWeatherService!
    var mPresenter: WeatherListPresenter!
    var mWeatherList: [Weather]?
    
    @IBOutlet weak var tableView: UITableView!
    
    func showErrorMessage(msg: String) {
        
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler:nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func showLoader() {
        
        let hud = HKProgressHUD.show(addedToView: self.view, animated: true)
        hud.label?.text = "Loading..."
    }
    
    func hideLoader() {
        
        _ = HKProgressHUD.hide(addedToView: self.view, animated: false)
    }
    
    func showWeatherList(weatherList: [Weather]) {
        
        self.mWeatherList = weatherList
        self.tableView.reloadData()
    }
    
    func navigateToWeatherDetail() {
        
        performSegue(withIdentifier: DetailSegue, sender: self)
    }
    
    func showSettingsScreen() {
        
        performSegue(withIdentifier: SettingsSegue, sender: self)
    }
    
    func getData() {
        
        mPresenter.getWeather(forCity: City)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Dubai Weather"
        
        self.tableView.register(UINib.init(nibName: "WeatherTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: "WeatherTableViewCell")
        
        self.tableView.rowHeight = UITableView.automaticDimension
        
        self.tableView.estimatedRowHeight = 80
        
        // Register to receive notification in your class
        NotificationCenter.default.addObserver(self, selector: #selector(self.tempratureNotationChanged(_:)), name: NSNotification.Name(rawValue:TempratureNotationChanged), object: nil)
        
        mWeatherService = WeatherService()
        
        mPresenter = WeatherListPresenter(withVisitService: mWeatherService, weatherListView: self)
        
        self.getData()
        
    }
    
    @objc func tempratureNotationChanged(_ notification: NSNotification) {
        
        self.getData()
    }
    
    // MARK: - Table view data source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.mWeatherList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "WeatherTableViewCell", for: indexPath) as! WeatherTableViewCell
        
        let weather = self.mWeatherList?[indexPath.row]
        
        cell.dateLabel.text = weather?.date
        cell.tempratureLabel.text = weather?.temprature
        
        
        cell.selectionStyle = .none
        return cell;
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension;
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        self.mPresenter.weatherCellTapped()
    }
    
    
    // MARK: - IBActions
    
    @IBAction func settingsButtonAction(_ sender : AnyObject){
        
        self.mPresenter.settingsButtonTapped()
        
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == DetailSegue) {
            // pass data to next view
            let viewController = segue.destination as? WeatherDetailViewController
            let indexpath = self.tableView.indexPathForSelectedRow
            if let row = indexpath?.row {
                viewController!.mWeather = self.mWeatherList?[row]
            }
            
            
        }
    }
    
    
}






//}
