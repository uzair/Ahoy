//
//  WeatherService.swift
//  AhoyTest
//
//  Created by Uzair on 07/12/2020.
//

import UIKit
import Alamofire


protocol IWeatherService {
    
    func getWeather(forCity city: String?,withTempratureNotation tempratureNotation: TempratureNotation?, completion: @escaping (Response<[Weather]>) -> ())
    
    
}

class WeatherService: IWeatherService {
    
    func getWeather(forCity city: String?,withTempratureNotation tempratureNotation: TempratureNotation?, completion: @escaping (Response<[Weather]>) -> ())
    
    {
        if (!Utility.isConnectedToInternet()){
            
            if let weatherForecast = Utility.getOfflineData() as? [Weather] {
                
                completion(Response<[Weather]>(withData: weatherForecast))
                return
                
            }
            else {
                
                completion(Response(withFailureMessage: "Internet not connected"))
                return
            }
        }
        
        guard let city = city else {
            completion(Response(withFailureMessage: "City name is empty"))
            return
        }
        
        guard let tempratureNotation = tempratureNotation else {
            completion(Response(withFailureMessage: "Temprature notation name is empty"))
            return
        }
        
        var tempratureUnit = ""
        switch tempratureNotation {
        case .celcius:
            tempratureUnit = "metric"
            break
        case .fahrenheit:
            tempratureUnit = "imperial"
            break
            
        }
        
        let url = String(format:"%@%@&appid=%@&units=%@",WebServiceUrl.weatherUrl, city, WebServiceUrl.apiKey,tempratureUnit)
        
        
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
            .responseJSON { response in
                
                switch response.result {
                
                case .success(let json):
                    
                    if let result = json as? Dictionary<String, AnyObject> {
                        
                        if let list = result["list"] as? [[String:AnyObject]] {
                            
                            var distinctDates = [String]()
                            var distinctDatesWeather = [Dictionary<String, AnyObject>]()
                            
                            for dict in list {
                                
                                if let timeInterval = dict["dt"] as? Double{
                                    
                                    let dateStr = timeInterval.getDateStringFromUTC()
                                    
                                    if (!distinctDates.contains(dateStr)){
                                        distinctDates.append(dateStr)
                                        distinctDatesWeather.append(dict)
                                        
                                    }
                                    
                                }
                            }
                            
                            
                            var weatherForceast = [Weather]()
                            
                            
                            for (index, element) in distinctDatesWeather.enumerated() {
                                
                                let weatherDict = element
                                
                                let weather = Weather()
                                
                                let dateStr = distinctDates[index]
                                
                                if let tempratureDict = weatherDict["main"] as? Dictionary<String,Any> {
                                    
                                    let feelsLike = (tempratureDict["feels_like"] as? NSNumber)?.stringValue
                                    
                                    let minimumTemp = (tempratureDict["temp_min"] as? NSNumber)?.stringValue
                                    
                                    let maximumTemp = (tempratureDict["temp_max"] as? NSNumber)?.stringValue
                                    
                                    let humidity = (tempratureDict["humidity"] as? NSNumber)?.stringValue
                                    
                                    let temprature = (tempratureDict["temp"] as? NSNumber)?.stringValue
                                    
                                    weather.date = dateStr
                                    weather.temprature = temprature
                                    weather.feelsLike = feelsLike
                                    weather.minimumTemprature = minimumTemp
                                    weather.maximumTemprature = maximumTemp
                                    weather.humidity = humidity
                                    
                                    weatherForceast.append(weather)
                                    
                                    
                                }
                                
                            }
                            
                            Utility.saveDataForOfflineUsage(withData: weatherForceast)
                            
                            completion(Response<[Weather]>(withData: weatherForceast))
                            // send the response back here //
                            
                        }
                        
                    }
                    
                    
                case .failure(let error):
                    print(error)
                    completion(Response(withFailureMessage: "Could not parse response"))
                }
            }
        
    }
    
}
