//
//  IAttachmentListView.swift
//  JobLogic
//
//  Created by Uzair Shahzad on 10/13/20.
//  Copyright © 2020 JobLogic. All rights reserved.
//

import Foundation

protocol IWeatherListView{

    func showErrorMessage(msg:String)
    func showLoader()
    func hideLoader()
    func showWeatherList(weatherList:[Weather])
    func navigateToWeatherDetail()
    func showSettingsScreen()


    
}
