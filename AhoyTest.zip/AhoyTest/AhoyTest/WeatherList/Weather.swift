//
//  Weather.swift
//  AhoyTest
//
//  Created by Uzair on 07/12/2020.
//

import Foundation

class Weather: NSObject, NSCoding {
    func encode(with coder: NSCoder) {
        
        coder.encode(date, forKey: "date")
        coder.encode(temprature, forKey: "temprature")
        coder.encode(feelsLike, forKey: "feelsLike")
        coder.encode(minimumTemprature, forKey: "minimumTemprature")
        coder.encode(maximumTemprature, forKey: "maximumTemprature")
        coder.encode(humidity, forKey: "humidity")
    }
    
    override init() {}
    
    required init?(coder: NSCoder) {
        
        date = coder.decodeObject(forKey: "date") as? String ?? ""
        temprature = coder.decodeObject(forKey: "temprature") as? String ?? ""
        feelsLike = coder.decodeObject(forKey: "feelsLike") as? String ?? ""
        minimumTemprature = coder.decodeObject(forKey: "minimumTemprature") as? String ?? ""
        maximumTemprature = coder.decodeObject(forKey: "maximumTemprature") as? String ?? ""
        humidity = coder.decodeObject(forKey: "humidity") as? String ?? ""
    }
    
    
    var date: String?
    var temprature: String?
    var feelsLike: String?
    var minimumTemprature: String?
    var maximumTemprature: String?
    var humidity: String?

}
