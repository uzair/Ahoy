//
//  WeatherDetailViewController.swift
//  AhoyTest
//
//  Created by Uzair on 07/12/2020.
//

import UIKit

class WeatherDetailViewController: UIViewController {
    
    var mWeather: Weather?
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var tempratureLabel: UILabel!
    @IBOutlet weak var feelsLikeLabel: UILabel!
    @IBOutlet weak var minimumTempLabel: UILabel!
    @IBOutlet weak var maximumTempLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.title = "Weather detail"
        
        self.dateLabel.text = self.mWeather?.date
        self.tempratureLabel.text = self.mWeather?.temprature
        self.feelsLikeLabel.text = self.mWeather?.feelsLike
        self.minimumTempLabel.text = self.mWeather?.minimumTemprature
        self.maximumTempLabel.text = self.mWeather?.maximumTemprature
        self.humidityLabel.text = self.mWeather?.humidity
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
